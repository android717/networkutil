package com.ravix.networkutils;

/**
 * Created by Ravix
 * Date: 08-07-2024
 * Time: 10:40
 */

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

public class NetworkUtil {

    private static NetworkUtil instance;
    private final ConnectivityManager connectivityManager;
    private final MutableLiveData<NetworkState> networkStateLiveData = new MutableLiveData<>();
    private final NetworkCallback networkCallback = new NetworkCallback();

    private NetworkUtil(Context context) {
        connectivityManager = (ConnectivityManager) context.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkRequest networkRequest = new NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build();
        connectivityManager.registerNetworkCallback(networkRequest, networkCallback);
        // Immediate check
        updateNetworkState();
    }

    public static synchronized NetworkUtil getInstance(Context context) {
        if (instance == null) {
            instance = new NetworkUtil(context);
        }
        return instance;
    }

    public LiveData<NetworkState> getNetworkState() {
        return networkStateLiveData;
    }

    public boolean isInternetAvailable() {
        updateNetworkState(); // Ensure state is up-to-date
        NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
        return networkCapabilities != null && networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }

    public void unregisterNetworkCallback() {
        if (connectivityManager != null && networkCallback != null) {
            connectivityManager.unregisterNetworkCallback(networkCallback);
        }
    }


    public void updateNetworkState() {
        NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(connectivityManager.getActiveNetwork());
        if (networkCapabilities != null) {
            int downSpeed = networkCapabilities.getLinkDownstreamBandwidthKbps();
            int upSpeed = networkCapabilities.getLinkUpstreamBandwidthKbps();
            boolean hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            SpeedCategory speedCategory = getSpeedCategory(downSpeed);
            NetworkState networkState = new NetworkState(downSpeed, upSpeed, hasInternet, speedCategory);
            networkStateLiveData.postValue(networkState);
        } else {
            networkStateLiveData.postValue(new NetworkState(0, 0, false, SpeedCategory.NO_INTERNET));
        }
    }


    private class NetworkCallback extends ConnectivityManager.NetworkCallback {
        @Override
        public void onAvailable(@NonNull Network network) {
            updateNetworkState();
        }

        @Override
        public void onLost(@NonNull Network network) {
            updateNetworkState();
        }

        @Override
        public void onCapabilitiesChanged(@NonNull Network network, @NonNull NetworkCapabilities networkCapabilities) {
            updateNetworkState();
        }
    }

    private SpeedCategory getSpeedCategory(int downSpeedKbps) {
        if (downSpeedKbps >= InternetConstants.Kbps_100000) { // 100 Mbps
            return SpeedCategory.VERY_HIGH;
        } else if (downSpeedKbps >= InternetConstants.Kbps_25000) { // 25 Mbps
            return SpeedCategory.HIGH;
        } else if (downSpeedKbps >= InternetConstants.Kbps_10000) { // 10 Mbps
            return SpeedCategory.MODERATE;
        } else if (downSpeedKbps >= InternetConstants.Kbps_3000) { // 3 Mbps
            return SpeedCategory.LOW;
        } else if (downSpeedKbps >= InternetConstants.Kbps_1000) { // 1 Mbps
            return SpeedCategory.VERY_LOW;
        } else {
            return SpeedCategory.NO_INTERNET;
        }
    }

    public static class NetworkState {
        private final int downSpeed;
        private final int upSpeed;
        private final boolean hasInternet;
        private final SpeedCategory speedCategory;

        public NetworkState(int downSpeed, int upSpeed, boolean hasInternet, SpeedCategory speedCategory) {
            this.downSpeed = downSpeed;
            this.upSpeed = upSpeed;
            this.hasInternet = hasInternet;
            this.speedCategory = speedCategory;
        }

        public int getDownSpeed() {
            return downSpeed;
        }

        public int getUpSpeed() {
            return upSpeed;
        }

        public boolean hasInternet() {
            return hasInternet;
        }

        public SpeedCategory getSpeedCategory() {
            return speedCategory;
        }

        @NonNull
        @Override
        public String toString() {
            return "Download Speed: " + downSpeed + " kbps\n" +
                    "Upload Speed: " + upSpeed + " kbps\n" +
                    "Has Internet: " + (hasInternet ? "Yes" : "No") + "\n" +
                    "Speed Category: " + speedCategory + "\n";
        }
    }

    public enum SpeedCategory {
        VERY_LOW,
        LOW,
        MODERATE,
        HIGH,
        VERY_HIGH,
        NO_INTERNET
    }
}
